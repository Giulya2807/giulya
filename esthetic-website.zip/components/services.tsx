import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Sparkles, Droplet, Heart, Zap, FileText } from "lucide-react"

const services = [
  {
    icon: Sparkles,
    title: "Tratamentos Faciais",
    description:
      "Limpeza de pele, peeling, microagulhamento, e tratamentos antienvelhecimento para revitalizar seu rosto.",
    treatments: ["Limpeza de Pele", "Peeling Químico", "Microagulhamento", "Rejuvenescimento"],
  },
  {
    icon: Droplet,
    title: "Estética Corporal",
    description: "Drenagem linfática, massagens modeladoras e tratamentos para redução de medidas e celulite.",
    treatments: ["Drenagem Linfática", "Massagem Modeladora", "Lipocavitação", "Criolipólise"],
  },
  {
    icon: Heart,
    title: "Bem-Estar",
    description: "Massagens relaxantes, aromaterapia e tratamentos holísticos para equilibrar corpo e mente.",
    treatments: ["Massagem Relaxante", "Aromaterapia", "Reflexologia", "Day Spa"],
  },
  {
    icon: Zap,
    title: "Tecnologias Avançadas",
    description: "Tratamentos com laser, radiofrequência e ultrassom para resultados mais eficazes.",
    treatments: ["Laser CO2", "Radiofrequência", "Ultrassom Microfocado", "LED Therapy"],
  },
]

export function Services() {
  return (
    <section id="servicos" className="py-24 md:py-32">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light text-foreground mb-4 text-balance">
            Nossos Serviços
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Oferecemos uma ampla gama de tratamentos estéticos personalizados para atender suas necessidades
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <Card key={index} className="border-border hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-start gap-4 mb-4">
                  <div className="p-3 rounded-full bg-primary/10">
                    <service.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-serif font-medium mb-2">{service.title}</h3>
                    <p className="text-muted-foreground leading-relaxed mb-4">{service.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {service.treatments.map((treatment, idx) => (
                        <span
                          key={idx}
                          className="text-xs px-3 py-1 rounded-full bg-secondary/50 text-secondary-foreground"
                        >
                          {treatment}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
            <a
              href="https://www.canva.com/design/DAG5nwAM2d0/KN7lJCnEJW1KV7x1O-8rVg/view?utm_content=DAG5nwAM2d0&utm_campaign=designshare&utm_medium=link2&utm_source=uniquelinks&utlId=h7a69fb13e2"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2"
            >
              <FileText className="h-5 w-5" />
              Ver Catálogo Completo de Serviços (PDF)
            </a>
          </Button>
        </div>
      </div>
    </section>
  )
}
