export function Gallery() {
  const images = [
    { url: "/spa-facial-treatment.png", alt: "Tratamento facial" },
    { url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/lvtemp_53fe553f-9888-46d9-b1af-6068e980a0884-gyvtaADLwXewD3sPxoL9pqQ5CkNtEJ.mp4", alt: "Vídeo da clínica", isVideo: true },
    { url: "/beauty-salon-interior.png", alt: "Interior da clínica" },
    { url: "/images/treatment-room.jpg", alt: "Sala de tratamento moderna" },
    { url: "/luxury-skincare-products.png", alt: "Produtos de skincare" },
    { url: "/spa-relaxation-room.jpg", alt: "Sala de relaxamento" },
    { url: "/beauty-treatment-professional.jpg", alt: "Atendimento profissional" },
  ]

  return (
    <section id="galeria" className="py-24 md:py-32 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light text-foreground mb-4 text-balance">
            Nosso Espaço
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Conheça nosso ambiente acolhedor e moderno, projetado para seu conforto e bem-estar
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-6">
          {images.map((image, index) => (
            <div key={index} className="relative aspect-square rounded-xl overflow-hidden group cursor-pointer">
              {image.isVideo ? (
                <video
                  src={image.url}
                  className="absolute inset-0 w-full h-full object-cover"
                  autoPlay
                  loop
                  muted
                  playsInline
                />
              ) : (
                <>
                  <img
                    src={image.url || "/placeholder.svg"}
                    alt={image.alt}
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-primary/0 group-hover:bg-primary/20 transition-colors duration-300" />
                </>
              )}
            </div>
          ))}
        </div>

        <div className="mt-12 lg:mt-16 max-w-5xl mx-auto">
          <div className="relative aspect-video w-full rounded-2xl overflow-hidden shadow-xl">
            <iframe
              className="absolute inset-0 w-full h-full"
              src="https://www.youtube.com/embed/56tIwLtxm8c?autoplay=1&mute=1&loop=1&playlist=56tIwLtxm8c"
              title="Vídeo da Clínica Bela Vista"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </div>
      </div>
    </section>
  )
}
