export function About() {
  return (
    <section id="sobre" className="py-24 md:py-32 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif font-light text-foreground mb-6 text-balance">
              Cuidado personalizado para sua beleza
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Na Bela Vista Estética, acreditamos que cada pessoa é única e merece um tratamento personalizado. Nossa
                equipe de profissionais especializados está comprometida em realçar sua beleza natural.
              </p>
              <p>
                Com mais de 10 anos de experiência, utilizamos as técnicas mais modernas e produtos de alta qualidade
                para garantir resultados excepcionais e duradouros.
              </p>
              <p>
                Nosso ambiente foi cuidadosamente projetado para proporcionar uma experiência relaxante e acolhedora,
                onde você pode se desconectar do dia a dia e focar no seu bem-estar.
              </p>
            </div>
          </div>
          <div className="relative h-[500px] rounded-2xl overflow-hidden">
            <img
              src="/images/1000452014-20-282-29.jpg"
              alt="Interior da clínica Bela Vista"
              className="absolute inset-0 w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
