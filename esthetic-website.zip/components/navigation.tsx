"use client"

import { Menu, X } from "lucide-react"
import { useState } from "react"

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      setIsOpen(false)
    }
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <button
            onClick={() => scrollToSection("hero")}
            className="text-2xl font-serif font-semibold text-foreground tracking-wide"
          >
            Bela Vista
          </button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollToSection("sobre")} className="text-sm hover:text-primary transition-colors">
              Sobre
            </button>
            <button
              onClick={() => scrollToSection("servicos")}
              className="text-sm hover:text-primary transition-colors"
            >
              Serviços
            </button>
            <button onClick={() => scrollToSection("galeria")} className="text-sm hover:text-primary transition-colors">
              Galeria
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button onClick={() => setIsOpen(!isOpen)} className="md:hidden p-2" aria-label="Toggle menu">
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden py-6 space-y-4 border-t border-border">
            <button
              onClick={() => scrollToSection("sobre")}
              className="block w-full text-left py-2 text-sm hover:text-primary transition-colors"
            >
              Sobre
            </button>
            <button
              onClick={() => scrollToSection("servicos")}
              className="block w-full text-left py-2 text-sm hover:text-primary transition-colors"
            >
              Serviços
            </button>
            <button
              onClick={() => scrollToSection("galeria")}
              className="block w-full text-left py-2 text-sm hover:text-primary transition-colors"
            >
              Galeria
            </button>
          </div>
        )}
      </div>
    </nav>
  )
}
